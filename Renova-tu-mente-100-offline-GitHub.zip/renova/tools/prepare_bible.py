#!/usr/bin/env python3
"""Download and bundle Reina-Valera 1909 for offline use in the APK."""
import json, urllib.request, re, os, sys
URL = 'https://raw.githubusercontent.com/Amosamevor/Bible-json/main/versions/es/REINA%20VALERA%201909.json'
DEST = os.path.join('app','src','main','assets','bible-data.js')
BOOKS = ['Genesis','Exodus','Leviticus','Numbers','Deuteronomy','Joshua','Judges','Ruth','1 Samuel','2 Samuel','1 Kings','2 Kings','1 Chronicles','2 Chronicles','Ezra','Nehemiah','Esther','Job','Psalms','Proverbs','Ecclesiastes','Song of Solomon','Isaiah','Jeremiah','Lamentations','Ezekiel','Daniel','Hosea','Joel','Amos','Obadiah','Jonah','Micah','Nahum','Habakkuk','Zephaniah','Haggai','Zechariah','Malachi','Matthew','Mark','Luke','John','Acts','Romans','1 Corinthians','2 Corinthians','Galatians','Ephesians','Philippians','Colossians','1 Thessalonians','2 Thessalonians','1 Timothy','2 Timothy','Titus','Philemon','Hebrews','James','1 Peter','2 Peter','1 John','2 John','3 John','Jude','Revelation']
ALIASES = {re.sub(r'[^a-z0-9]','',b.lower()):b for b in BOOKS}
ALIASES.update({'songofsongs':'Song of Solomon','canticles':'Song of Solomon','revelations':'Revelation','psalm':'Psalms','acts of the apostles':'Acts'})
def norm(s): return re.sub(r'[^a-z0-9]','',str(s).lower())
def get(d,*keys):
    if not isinstance(d,dict): return None
    for k in keys:
        if k in d: return d[k]
    return None
def book_name(v):
    if v is None: return None
    n=norm(v)
    return ALIASES.get(n) or ALIASES.get(n.replace('bookof',''))

def main():
    req=urllib.request.Request(URL,headers={'User-Agent':'RenovaTuMente-offline-bible-builder'})
    with urllib.request.urlopen(req,timeout=60) as r: raw=json.load(r)
    out={b:{} for b in BOOKS}
    flat=[]
    def add(b,c,v,t):
        if b in out and c and v and t is not None:
            flat.append((b,int(c),int(v),str(t).strip()))
    def walk(node, inherited_book=None, inherited_chapter=None, inherited_verse=None):
        if isinstance(node,list):
            for x in node: walk(x,inherited_book,inherited_chapter,inherited_verse)
            return
        if not isinstance(node,dict):
            # Nested mapping such as Book -> Chapter -> Verse -> text.
            if inherited_book and inherited_chapter and inherited_verse and isinstance(node,(str,int,float)):
                add(inherited_book,inherited_chapter,inherited_verse,node)
            return
        bn=book_name(get(node,'book','book_name','bookName','book_name_long','bookNameLong','nameLong')) or inherited_book
        if not bn: bn=book_name(get(node,'name','title','long_name','longName')) or inherited_book
        ch=get(node,'chapter','chapter_number','chapterNumber','chapterNum')
        vs=get(node,'verse','verse_number','verseNumber','verseNum')
        number=get(node,'number','num')
        txt=get(node,'text','verse_text','verseText','content','value')
        # Handle common hierarchical object shapes where number is chapter/verse.
        if ch is None and inherited_book and inherited_chapter is None and number is not None and str(number).isdigit() and get(node,'verses','verse') is not None:
            ch=number
        if vs is None and inherited_chapter is not None and number is not None and str(number).isdigit() and txt is not None:
            vs=number
        if isinstance(ch,dict): ch=get(ch,'number','num','id')
        if bn and ch is not None and vs is not None and txt is not None and str(ch).isdigit() and str(vs).isdigit():
            add(bn,ch,vs,txt)
        # If this is a verse record and its parent supplied book/chapter.
        if bn and inherited_chapter and vs is not None and txt is not None and str(vs).isdigit():
            add(bn,inherited_chapter,vs,txt)
        for k,v in node.items():
            child_book=book_name(k) or bn
            child_ch=inherited_chapter
            child_v=inherited_verse
            if isinstance(k,str) and k.isdigit():
                n=int(k)
                if child_book and child_ch is None and 1 <= n <= 150:
                    child_ch=n
                elif child_book and child_ch is not None and child_v is None and 1 <= n <= 200:
                    child_v=n
                    if isinstance(v,(str,int,float)):
                        add(child_book,child_ch,child_v,v)
            # Common key patterns: "chapter 1", "verse 2".
            km=re.match(r'(?i)^chapter\s*[_ -]?(\d+)$',str(k))
            if km: child_ch=int(km.group(1))
            vm=re.match(r'(?i)^verse\s*[_ -]?(\d+)$',str(k))
            if vm:
                child_v=int(vm.group(1))
                if child_book and child_ch and isinstance(v,(str,int,float)): add(child_book,child_ch,child_v,v)
            walk(v,child_book,child_ch,child_v)
    walk(raw)
    # Deduplicate entries caused by nested schema traversal and keep verse order.
    for b,c,v,t in flat:
        if b in out and c>0 and v>0:
            out[b].setdefault(str(c),[])
            if not any(x['verse']==v for x in out[b][str(c)]): out[b][str(c)].append({'verse':v,'text':t})
    for b in out:
        for c in out[b]: out[b][c].sort(key=lambda x:x['verse'])
    verses=sum(len(vs) for chapters in out.values() for vs in chapters.values())
    chapters=sum(len(chapters) for chapters in out.values())
    books=sum(bool(chapters) for chapters in out.values())
    if books < 66 or chapters < 1189 or verses < 30000:
        print(f'ERROR: Biblia incompleta tras normalizar: {books} libros, {chapters} capítulos, {verses} versículos. No se generó el archivo.',file=sys.stderr)
        print('La fuente JSON cambió de formato o no se pudo interpretar.',file=sys.stderr); sys.exit(1)
    os.makedirs(os.path.dirname(DEST),exist_ok=True)
    with open(DEST,'w',encoding='utf-8') as f: f.write('window.RTM_BIBLE='+json.dumps(out,ensure_ascii=False,separators=(',',':'))+';')
    print(f'Biblia offline preparada: {books} libros, {chapters} capítulos, {verses} versículos.')
if __name__=='__main__': main()
